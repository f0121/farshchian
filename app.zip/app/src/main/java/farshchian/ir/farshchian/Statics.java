package farshchian.ir.farshchian;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.Color;
import android.graphics.Typeface;
import android.util.DisplayMetrics;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.TextView;

public class Statics {

	static Context context;
	static Typeface font_yekan;
	
	public static Typeface getFontYekan(Context context){
		if(font_yekan == null){
			font_yekan = Typeface.createFromAsset(context.getAssets(),"fonts/iransans.ttf");
		}
		return font_yekan;
	}

	public static void setTint(Context context, String color){
		int API_LEVEL =  android.os.Build.VERSION.SDK_INT;
		if (API_LEVEL > 19){
			Window window = ((Activity)context).getWindow();
			window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
			window.clearFlags(WindowManager.LayoutParams.FLAG_TRANSLUCENT_STATUS);
			window.setStatusBarColor(Color.parseColor(color));
			window.setNavigationBarColor(Color.parseColor(color));
		}
	}
	public static void set_typefaces(Context context, TextView... textViews) {
		Typeface tf = Statics.getFontYekan(context);
		for(TextView tv : textViews){
			tv.setTypeface(tf);
		}
	}

    public static int DPtoPX(int dp){
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
    }
    public static int DPtoPX(double dp){
		final float scale = context.getResources().getDisplayMetrics().density;
		return (int) (dp * scale + 0.5f);
    }
    
    public static int PXtoDP(int px){
        Resources resources = context.getResources();
        DisplayMetrics metrics = resources.getDisplayMetrics();
        float dp = px / (metrics.densityDpi / 160f);
        return (int) dp;
    }

    public static void exitApp(Context context){
    	((Activity)context).finish();
        Intent intent = new Intent(Intent.ACTION_MAIN);
        intent.addCategory(Intent.CATEGORY_HOME);
        intent.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK);
        ((Activity)context).startActivity(intent);
    }

}


interface onShowEndInterface {
	void onShowEnd(View view);
	void onShowStart(View view);
}
